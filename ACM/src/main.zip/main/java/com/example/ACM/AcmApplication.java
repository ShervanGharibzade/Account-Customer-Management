package com.example.ACM;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.data.jpa.repository.config.EnableJpaAuditing;

@SpringBootApplication
@EnableJpaAuditing
public class AcmApplication {

	public static void main(String[] args) {
		SpringApplication.run(AcmApplication.class, args);
	}

}
